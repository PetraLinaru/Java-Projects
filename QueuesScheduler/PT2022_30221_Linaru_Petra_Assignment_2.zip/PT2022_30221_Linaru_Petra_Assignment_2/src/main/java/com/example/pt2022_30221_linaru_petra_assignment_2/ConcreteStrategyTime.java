package com.example.pt2022_30221_linaru_petra_assignment_2;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ConcreteStrategyTime implements Strategy{
    Scheduler scheduler;
    ConcreteStrategyTime(Scheduler scheduler)
    {
        this.scheduler=scheduler;
    }
    @Override
    public void addTask(List<Server> servers, Task t) {

    }
}
