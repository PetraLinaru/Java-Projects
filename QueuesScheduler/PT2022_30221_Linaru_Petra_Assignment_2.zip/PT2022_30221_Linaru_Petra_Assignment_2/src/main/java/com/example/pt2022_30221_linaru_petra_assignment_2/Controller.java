package com.example.pt2022_30221_linaru_petra_assignment_2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    SimulationManager sim= new SimulationManager();
    View v= new View(sim);

    @FXML
    private AnchorPane pane;
    @FXML
    private TextField box1;
    @FXML
    private TextField box2;
    @FXML
    private TextField box3;
    @FXML
    private TextField box4;
    @FXML
    private TextField box5;
    ObservableList<String> queueStrategy= FXCollections.observableArrayList("Shortest Time", "Shortest Queue");
    @FXML
    private Button nextBtn;
    @FXML
    private ChoiceBox strBox;

    public Controller() throws IOException {
    }

    public void box1Txt(ActionEvent actionEvent) {
        sim.timeLimit=Integer.parseInt(box1.getText());

    }

    public void box2Txt(ActionEvent actionEvent) {
        sim.maxProcessingTime=Integer.parseInt(box2.getText());
    }

    public void box3Txt(ActionEvent actionEvent) {
        sim.minProcessingTime=Integer.parseInt(box3.getText());
    }

    public void box4Txt(ActionEvent actionEvent) {
        sim.numberOfServers=Integer.parseInt(box4.getText());
    }

    public void box5Ttxt(ActionEvent actionEvent) {
        sim.numberOfClients=Integer.parseInt(box5.getText());
    }
    @FXML
    public void strBoxAct(MouseEvent mouseEvent) {
        strBox.setItems(queueStrategy);


    }


    public void nextBtnAct(ActionEvent actionEvent) {
        nextBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage stage= new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Simulation.fxml"));
                Scene scene = null;
                try {
                    scene = new Scene(fxmlLoader.load(), 670, 490);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                stage.setTitle("Your Queue App!");
                    stage.setScene(scene);
                    stage.showAndWait();
                }

            });
        }
    }

