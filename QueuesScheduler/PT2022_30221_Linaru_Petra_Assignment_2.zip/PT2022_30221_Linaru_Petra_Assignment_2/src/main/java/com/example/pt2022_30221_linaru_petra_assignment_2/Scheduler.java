package com.example.pt2022_30221_linaru_petra_assignment_2;


import java.util.ArrayList;
import java.util.List;

public class Scheduler {
    private List<Server> servers;
    private  int MaxNoServers;
    private int maxTasksPerServer;
    Thread[] serverThreads;
    private Strategy strategy;

    public Scheduler(int maxNoServers, int maxTasksPerServer){
       this.MaxNoServers=maxNoServers;
        this.maxTasksPerServer=maxTasksPerServer;
        this.serverThreads=new Thread[maxNoServers];
        this.servers=new ArrayList<Server>(maxNoServers);

          for(int i=0;i<maxNoServers;i++)
          {
              Server firstServer=new Server(maxTasksPerServer);
              servers.add(firstServer);
              serverThreads[i]=new Thread(firstServer);
          }
          for( int i=0;i<maxNoServers;i++)
          {
              serverThreads[i].start();
          }
    }

    public void changeStrategy(SelectionPolicy policy)
    {
        if(policy == SelectionPolicy.SHORTEST_QUEUE){
             strategy = new ConcreteStrategyQueue();
        }
        if(policy == SelectionPolicy.SHORTEST_TIME){
           strategy= new ConcreteStrategyTime(this);
        }
    }

    public Server dispatchTask(Task t) throws InterruptedException {
        int maxTime = servers.get(0).getWaitingPeriod();
        //caut sa vad care e cel mai mic timp de asteptare
        //iterez prin servere si caut de ex in servere (mai multe blockingqueues)
        // si caut coada cu cel mai mic timp de asteptare
        for (int i = 0; i < MaxNoServers; i++) {
            if (servers.get(i).getWaitingPeriod() <= maxTime) {
                maxTime = servers.get(i).getWaitingPeriod();
            }
        }
        //apoi introduc task-ul/clientul in coada resp
        int atPosition=0;
        for (int i = 0; i < MaxNoServers; i++) {
            if (servers.get(i).getWaitingPeriod() == maxTime) {
                servers.get(i).addTask(t);
                atPosition=i;
                break;
            }
        }
        return servers.get(atPosition);
    }
    public List<Server> getServers()
    {
        return  this.servers;
    }

}