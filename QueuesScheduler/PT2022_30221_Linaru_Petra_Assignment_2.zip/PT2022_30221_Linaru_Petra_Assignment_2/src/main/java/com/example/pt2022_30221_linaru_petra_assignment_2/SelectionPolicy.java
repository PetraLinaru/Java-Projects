package com.example.pt2022_30221_linaru_petra_assignment_2;

public enum SelectionPolicy {SHORTEST_QUEUE, SHORTEST_TIME}
