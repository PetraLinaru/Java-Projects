package com.example.pt2022_30221_linaru_petra_assignment_2;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Server implements Runnable {
    private BlockingQueue<Task> tasks;
    private int waitingPeriod;
    private int quantity;


    public int getWaitingPeriod() {
        return waitingPeriod;
    }

    public int getQuantity() {
        return quantity;
    }

    public Server(int quantity){
        this.quantity=quantity;
        this.waitingPeriod=0;
        tasks=new ArrayBlockingQueue<>(quantity);
    }

    public void addTask(Task newTask) throws InterruptedException {
        tasks.put(newTask);
        int timeToWait=newTask.getProcessingTime();
        waitingPeriod+= newTask.getProcessingTime();
    }


    @Override
    public void run() {
        Task t;
        while(true){
            try{
                t=tasks.take();  //scot cate un task
                Thread.sleep(t.getProcessingTime()*100);
                System.out.println(t.toString());
                waitingPeriod=waitingPeriod-t.getProcessingTime(); // Scad din waitingPeriod timpul de asteptare pt task ul in desf
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


    }

    public Task[] getTasks()
    {    Task[] listOfTasks= new Task[quantity];
        int i=0;
        for(Task t:tasks)
        {
            listOfTasks[i]=t;
            i++;
        }
        return listOfTasks;
    }



}