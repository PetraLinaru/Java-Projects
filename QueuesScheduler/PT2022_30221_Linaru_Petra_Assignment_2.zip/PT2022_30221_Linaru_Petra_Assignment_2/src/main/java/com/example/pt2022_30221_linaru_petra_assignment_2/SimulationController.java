package com.example.pt2022_30221_linaru_petra_assignment_2;

import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;

public class SimulationController {

    int numberofServers;
    int numberofClients;
    public static TextArea[] queue1;
    public AnchorPane pane;
    public SimulationController(int numberofServers)
    {
        this.numberofServers=numberofServers;
        queue1=new TextArea[numberofServers];

        for(int i=0;i<numberofServers;i++)
        {
            queue1[i]=new TextArea();

        }
    }

    static void displayClients(int positionAt, Task t)
    {
        int toDisplay=positionAt;
        queue1[positionAt].setText(t.toString());
    }
}

