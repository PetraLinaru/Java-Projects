package com.example.pt2022_30221_linaru_petra_assignment_2;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;

public class SimulationManager implements Runnable{
    public int timeLimit=500;  //1
    public int maxProcessingTime=400; //2
    public int minProcessingTime=100; //3
    public int numberOfServers=20; //4
    public int numberOfClients=100;  //5
    private Scheduler scheduler;
    private SimulationController simulation;
    private List<Task> generatedTasks;

    public SimulationManager()
    {
        this.scheduler = new Scheduler(numberOfServers,numberOfClients); //un client=1 task
        simulation=new SimulationController(numberOfServers);
        for(int i=0;i<numberOfClients;i++)
        {
            generateNRandomTasks();
        }


    }
    @Override
    public void run() {
        int currentTime = 0;
        int elementIndex=0;
        while (currentTime < timeLimit) {
            for (Task t : generatedTasks) {
                if (t.getArrivalTime() == currentTime) {
                    try {
                        this.scheduler.dispatchTask(t);
                        System.out.println(t.toString());
                        t.setId_task(-10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }


                }

                currentTime++;
             try { simulation.displayClients(currentTime,t);
                   wait(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
              }
            }

        }
    }

        public void generateNRandomTasks(){
            Random rand= new Random();
            generatedTasks=new ArrayList<Task>(numberOfClients);

            for(int i=1;i<=numberOfClients;i++){
              int arrivalTime= rand.nextInt(minProcessingTime);
              int processingTime= rand.nextInt(maxProcessingTime);
              if(processingTime<minProcessingTime)
              {
                  processingTime=processingTime*2+minProcessingTime;
              }
                if(processingTime>maxProcessingTime)
                {
                    processingTime=processingTime-maxProcessingTime/2;
                }
              generatedTasks.add(new Task(i,arrivalTime,processingTime));
            }

            this.sort();

        }






    private SimulationManager sort() {
        Collections.sort(generatedTasks, new Comparator<Task>() {
            @Override
            public int compare(Task o1, Task o2) {
                return Integer.valueOf(o1.getArrivalTime()).compareTo(Integer.valueOf(o2.getArrivalTime()));
            }
        });
        return this;


    }


    public static void main(String[] args) throws IOException {

       HelloApplication.main(args);
        SimulationManager gen=new SimulationManager();
        Thread t=new Thread(gen);
        t.start();
    }
}
