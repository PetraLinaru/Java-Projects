package com.example.pt2022_30221_linaru_petra_assignment_2;


import java.util.List;

public interface Strategy {
    public void addTask(List<Server> servers,Task t);

}

