package com.example.pt2022_30221_linaru_petra_assignment_2;
import java.util.Random;

public class Task {
    public Task(int id_task, int arrivalTime, int processingTime) {
        this.id_task = id_task;
        this.arrivalTime = arrivalTime;
        this.processingTime = processingTime;
    }

    public Task() {

    }

    private int id_task;
    private int arrivalTime;
    private int processingTime;

    public void setId_task(int id_task) {
        this.id_task = id_task;
    }

    public int getId_client() {
        return id_task;
    }


    public int getArrivalTime() {
        return arrivalTime;
    }


    public int getProcessingTime() {
        return processingTime;
    }


    @Override
    public String toString() {
        return "Task{" +
                "ID_Task=" + this.getId_client() +
                ", arrivalTime=" + this.getArrivalTime() +
                ", processingTime=" + this.processingTime +
                '}';
    }
}



